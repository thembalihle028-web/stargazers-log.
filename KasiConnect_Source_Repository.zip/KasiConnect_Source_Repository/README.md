# KasiConnect — ASA 23 Shark Tank App Pitch

A mobile-first community business directory prototype created for the Morning AI Skills Acceleration 23 (ASA 23) App Pitch project.

## Files
- `index.html` — app structure and content
- `style.css` — responsive dark-blue design and layouts
- `script.js` — sample directory, category filtering, search, area filtering, mobile navigation, and listing form validation
- `KasiConnect_Shark_Tank_Pitch.pptx` — 8-slide pitch deck

## Run locally
Open `index.html` in a browser. No build step is required.

## Deploy for a live URL
This folder is a static website and can be deployed using a static hosting provider such as Netlify Drop or GitHub Pages:
1. Sign in to your chosen hosting provider.
2. Upload this project folder (or push it to a repository).
3. Follow the provider's deployment instructions.
4. Open the generated public URL and test the app on desktop and mobile.

A live public URL cannot be created from this workspace because deployment requires your hosting account and explicit publishing action.

## Prototype limitations
- Business entries are fictional sample data and are clearly intended for demonstration only.
- The listing form validates data in the browser only. It does not send or permanently save submissions.
- There is no authentication, database, geolocation, or real contact integration.
- Replace sample listings with verified listings and add a secure backend before public production use.

## Pitch positioning
**KasiConnect — Local Businesses. Local Opportunities.**
Proposed value: help residents discover local services and help community businesses become more visible. Demand and revenue assumptions should be validated with community research.
