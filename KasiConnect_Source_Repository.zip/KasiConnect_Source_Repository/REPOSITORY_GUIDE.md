# KasiConnect Source Repository Guide

## Project
KasiConnect is a responsive front-end prototype for discovering local community businesses and services.

## Files
- `index.html` — page structure and content
- `style.css` — styling and responsive layouts
- `script.js` — search, category/area filtering, mobile navigation, and demo form validation
- `README.md` — project overview and instructions
- `.gitignore` — common files Git should ignore

## Run locally
Open `index.html` in a modern web browser. No build step is required.

## Publish on Netlify Drop
1. Extract this ZIP file.
2. Open https://app.netlify.com/drop.
3. Drag the extracted `KasiConnect_Source_Repository` folder (the one containing `index.html`) into the upload area.
4. Wait for Netlify to create a public `netlify.app` URL.

## Upload to GitHub
1. Sign in to GitHub and create a new repository named `KasiConnect`.
2. For a simple public school-project repository, choose Public if you are comfortable sharing the source code.
3. Use **Add file → Upload files** and upload the files inside this folder, including `index.html`, `style.css`, `script.js`, `README.md`, `.gitignore`, and this guide.
4. Commit the upload. Copy the repository URL for your submission.

## Prototype limitations
The listings are sample/demo content and should not be presented as verified real businesses. The contact form is client-side demo validation only; it does not send or permanently store submissions. No backend, user accounts, or database are included.
